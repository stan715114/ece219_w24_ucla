Instructions:
● Codes are saved in one python file, Project3.ipynb
● Open with Google Colab (preferred) or jupyter notebook with environment set up
● Please run every problem one by one from beginning to end
● Refer to ECE219_Project3_Report.pdf for more details.
● Questions are answered below each code block

Files:
● Project2.ipynb
● ECE219_Project3_report.pdf
● feature_list.pkl
● data1.csv
● Synthetic_Movie_Lens dataset. https://drive.google.com/drive/folders/1_JF9plSjE3PAFBuSvUFRkDdftJWo1TFz?usp=drive_link
● MSLR-WEB10K dataset. https://www.microsoft.com/en-us/research/project/mslr/