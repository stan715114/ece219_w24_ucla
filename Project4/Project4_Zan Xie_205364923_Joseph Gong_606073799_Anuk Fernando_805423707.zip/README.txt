Instructions:
● Codes are saved in two seperate jupyter notebook files, Project4.ipynb, and tweet_data_project.jpynb
● Open with Google Colab (preferred) or jupyter notebook with environment set up
● Please run every problem one by one from beginning to end
● Refer to ECE219_Project4_Report.pdf for more details.
● Questions are answered below each code block

Files:
● Project4.ipynb
● tweet_data_project.jpynb
● ECE219_Project4_Report.pdf
● ECE_219_W_2024_P4.pdf